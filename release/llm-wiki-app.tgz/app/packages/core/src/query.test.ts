import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";

import type { LlmClient } from "@llm-wiki/llm";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { openInMemoryDb, type Db } from "./db";
import { indexPageForSearch, upsertPage } from "./db-pages";
import { listUsageRows } from "./db-usage";
import { createPage, PageAlreadyExistsError } from "./editor";
import { queryWiki } from "./query";
import type { QueryResponse } from "./schema";
import { initWikiFolder, readPage, writePage } from "./wiki";

function stubClient(responses: QueryResponse[]): LlmClient {
  const queue = [...responses];
  return {
    chat: {
      completions: {
        create: vi.fn(async () => {
          const next = queue.shift();
          if (!next) throw new Error("stub LLM: no canned response left");
          return {
            id: "stub",
            model: "stub/sonnet",
            choices: [
              {
                index: 0,
                message: { role: "assistant", content: JSON.stringify(next) },
                finish_reason: "stop",
              },
            ],
            usage: { prompt_tokens: 2500, completion_tokens: 320 },
          };
        }),
      },
    },
  } as unknown as LlmClient;
}

let wikiPath: string;
let db: Db;

beforeEach(async () => {
  wikiPath = await mkdtemp(join(tmpdir(), "llm-wiki-query-test-"));
  await initWikiFolder(wikiPath);
  db = openInMemoryDb();
});

afterEach(async () => {
  db.close();
  await rm(wikiPath, { recursive: true, force: true });
});

async function seed(slug: string, title: string, body: string) {
  await writePage(wikiPath, {
    slug,
    frontmatter: {
      title,
      slug,
      type: "concept",
      created: "2026-01-01",
      updated: "2026-01-01",
    },
    content: body,
  });
  upsertPage(db, {
    slug,
    title,
    type: "concept",
    created_at: "2026-01-01",
    updated_at: "2026-01-01",
    word_count: body.split(/\s+/).length,
    tags: [],
  });
  indexPageForSearch(db, { slug, title, content: body, tags: [] });
}

describe("queryWiki", () => {
  it.each([
    [
      "links override titles and FTS",
      "[[issue-hart-poc-gaps]] Operation HART",
      ["issue-hart-poc-gaps"],
    ],
    [
      "Chinese title excludes FTS extras",
      "请仅依据“HART章节试点证据缺口” HART 回答",
      ["issue-hart-poc-gaps"],
    ],
    ["bare slug excludes FTS extras", "issue-hart-poc-gaps HART", ["issue-hart-poc-gaps"]],
    [
      "multiple links are deduplicated",
      "[[issue-hart-poc-gaps]] [[operation-hart]] [[issue-hart-poc-gaps|重复]] HART",
      ["issue-hart-poc-gaps", "operation-hart"],
    ],
    ["missing links do not fall back", "[[missing-page]] HART", []],
    ["ordinary questions use FTS", "HART", ["issue-hart-poc-gaps", "operation-hart"]],
  ])("%s", async (_name, question, expected) => {
    await seed("issue-hart-poc-gaps", "HART 章节试点证据缺口", "HART ISSUE_BODY");
    await seed("operation-hart", "Operation", "HART OPERATION_BODY");
    const client = stubClient([
      {
        answer: "test",
        pagesUsed: [],
        suggestedNewPage: null,
        confidence: "low",
        caveats: [],
      },
    ]);
    await queryWiki({ question: question as string, wikiPath, db, client, model: "stub/sonnet" });
    const request = vi.mocked(client.chat.completions.create).mock.calls[0]![0];
    const system = String(request.messages[0]!.content);
    const loaded = Array.from(system.matchAll(/\(slug: ([a-z0-9-]+), type:/g), (m) => m[1]);
    expect(loaded.sort()).toEqual([...(expected as string[])].sort());
  });

  // Guards the deliberate-product-name carve-out: a bare single-segment slug
  // ("const810") is usually a product name dropped in passing, so FTS must still
  // top the selection up. Narrowing here is what starved answers of every
  // sibling page (the bug f480fb8 fixed).
  it("bare single-segment slug keeps the FTS top-up", async () => {
    // Both pages mention the product, mirroring the real failure: a product
    // name appears all over the wiki, so narrowing on it would answer from the
    // product page alone and starve the sibling page out.
    await seed("const810", "ConST810", "HART CONST810_BODY");
    await seed("operation-hart", "Operation", "HART CONST810 OPERATION_BODY");
    const client = stubClient([
      {
        answer: "test",
        pagesUsed: [],
        suggestedNewPage: null,
        confidence: "low",
        caveats: [],
      },
    ]);
    await queryWiki({
      question: "const810",
      wikiPath,
      db,
      client,
      model: "stub/sonnet",
    });
    const request = vi.mocked(client.chat.completions.create).mock.calls[0]![0];
    const system = String(request.messages[0]!.content);
    const loaded = Array.from(system.matchAll(/\(slug: ([a-z0-9-]+), type:/g), (m) => m[1]);
    expect(loaded.sort()).toEqual(["const810", "operation-hart"]);
  });

  it("rejects oversized explicit selections before calling the model", async () => {
    const client = stubClient([]);
    const question = Array.from({ length: 11 }, (_, i) => `[[page-${i}]]`).join(" ");
    await expect(
      queryWiki({ question, wikiPath, db, client, model: "stub/sonnet" }),
    ).rejects.toThrow("at most 10 pages");
    expect(client.chat.completions.create).not.toHaveBeenCalled();
  });

  it("loads a page named explicitly by wiki slug even when the FTS question does not match", async () => {
    await seed("issue-hart-poc-gaps", "HART 章节试点证据缺口", "## 阻塞项\n\n1. 缺少验证结果。\n");
    const client = stubClient([
      {
        answer: "[[issue-hart-poc-gaps]]",
        pagesUsed: ["issue-hart-poc-gaps"],
        suggestedNewPage: null,
        confidence: "high",
        caveats: [],
      },
    ]);

    await queryWiki({
      question: "请逐字读取 [[issue-hart-poc-gaps]]，不要改写。",
      wikiPath,
      db,
      client,
      model: "stub/sonnet",
    });

    const create = client.chat.completions.create as ReturnType<typeof vi.fn>;
    const request = create.mock.calls[0]?.[0] as {
      messages: Array<{ role: string; content: string }>;
    };
    expect(request.messages[0]?.content).toContain("缺少验证结果");
  });

  it("loads a page when its human-readable title is mentioned", async () => {
    await seed("issue-hart-poc-gaps", "HART 章节试点证据缺口", "## 允许动作\n\n1. 补充证据。\n");
    const client = stubClient([
      {
        answer: "[[issue-hart-poc-gaps]]",
        pagesUsed: ["issue-hart-poc-gaps"],
        suggestedNewPage: null,
        confidence: "high",
        caveats: [],
      },
    ]);

    await queryWiki({
      question: "请仅依据“HART章节试点证据缺口”页面原文回答。",
      wikiPath,
      db,
      client,
      model: "stub/sonnet",
    });

    const create = client.chat.completions.create as ReturnType<typeof vi.fn>;
    const request = create.mock.calls[0]?.[0] as {
      messages: Array<{ role: string; content: string }>;
    };
    expect(request.messages[0]?.content).toContain("补充证据");
  });

  it("returns the LLM's parsed answer and records usage", async () => {
    await seed("shors-algorithm", "Shor's Algorithm", "Quantum factoring in polynomial time.");

    const response: QueryResponse = {
      answer: "[[shors-algorithm]] factors integers in polynomial time.",
      pagesUsed: ["shors-algorithm"],
      suggestedNewPage: null,
      confidence: "high",
      caveats: [],
    };
    const client = stubClient([response]);

    const r = await queryWiki({
      question: "What is Shor's algorithm?",
      wikiPath,
      db,
      client,
      model: "stub/sonnet",
    });

    expect(r.answer).toContain("[[shors-algorithm]]");
    expect(r.pagesUsed).toEqual(["shors-algorithm"]);
    expect(r.confidence).toBe("high");

    const usage = listUsageRows(db);
    expect(usage).toHaveLength(1);
    expect(usage[0]?.operation).toBe("query");
  });

  it("includes a suggested new page when the LLM proposes one", async () => {
    const response: QueryResponse = {
      answer: "I'd want a dedicated page for this.",
      pagesUsed: [],
      suggestedNewPage: {
        slug: "quantum-error-correction",
        title: "Quantum Error Correction",
        content: "Overview of QEC schemes.\n",
        reason: "Frequently referenced; worth a standalone page.",
      },
      confidence: "medium",
      caveats: ["The wiki only covers Shor's algorithm so far."],
    };
    const client = stubClient([response]);

    const r = await queryWiki({
      question: "How does QEC fit in?",
      wikiPath,
      db,
      client,
      model: "stub/sonnet",
    });

    expect(r.suggestedNewPage?.slug).toBe("quantum-error-correction");
    expect(r.caveats).toHaveLength(1);
  });

  it("rejects an empty question", async () => {
    const client = stubClient([
      {
        answer: "",
        pagesUsed: [],
        suggestedNewPage: null,
        confidence: "low",
        caveats: [],
      },
    ]);
    await expect(
      queryWiki({ question: "", wikiPath, db, client, model: "stub/sonnet" }),
    ).rejects.toThrow(/non-empty/);
  });
});

describe("createPage", () => {
  it("writes a new page with frontmatter, DB row, FTS5 index, and log entry", async () => {
    const page = await createPage(wikiPath, db, {
      slug: "new-concept",
      title: "New Concept",
      type: "concept",
      content: "Body referring to [[other-page]].",
      tags: ["promoted"],
    });

    expect(page.frontmatter.title).toBe("New Concept");
    expect(page.frontmatter.tags).toEqual(["promoted"]);

    const round = await readPage(wikiPath, "new-concept");
    expect(round.content).toContain("[[other-page]]");
  });

  it("throws PageAlreadyExistsError when slug already exists", async () => {
    await createPage(wikiPath, db, {
      slug: "dup",
      title: "Dup",
      type: "concept",
      content: "first",
    });
    await expect(
      createPage(wikiPath, db, {
        slug: "dup",
        title: "Dup 2",
        type: "concept",
        content: "second",
      }),
    ).rejects.toBeInstanceOf(PageAlreadyExistsError);
  });
});
